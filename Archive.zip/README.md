# Yonoma PHP SDK

The official PHP client library for the Yonoma Email Marketing API

## Installation

```bash
composer require yonoma/email-marketing